﻿namespace TestAssignment.BL.Abstraction
{
    public interface IElement
    {
        public int Number { get; set; }
        public string Body { get; }
    }
}
