﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestAssignment.BL.Abstraction;

namespace TestAssignment.BL.Impl
{
    public class ElementMerger : IElementMerger
    {
        private static ElementMerger elementMerger;

        private ElementMerger(){}

        public static ElementMerger Get()
        {
            if (elementMerger == null)
                elementMerger = new ElementMerger();
            return elementMerger;
        }

        public IEnumerable<IElement> MergeElements(IEnumerable<IElement> elements, IElement newElement)
        {
            var newColection = new List<IElement>();
            int index = -1;

            for (int i = 0; i < elements.Count(); i++)
            {
                if (elements.ElementAt(i).Number >= newElement.Number && index < 0)
                {
                    newColection.Insert(i, newElement);
                    index = i;
                }
                newColection.Add(elements.ElementAt(i));
            }
            newColection = newColection.OrderBy(x => x.Number).ToList();
            if (newColection.Count() == elements.Count())       //если Number newElement больше каждого из листа(добавили в конец, сортировать, инкр. Number не нужно)
            {
                newColection.Add(newElement);
                return newColection;
            }
            index++;
            do
            {
                newColection[index].Number++;
                if (newColection[index].Number - newColection[index + 1].Number < 0)
                    return newColection;
                index++;
            } while (index < newColection.Count());
            return newColection;
        }
    }
}
